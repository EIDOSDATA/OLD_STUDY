#include <stdio.h>

int main()
{
    int a = 100;
    int *pa;
    pa = &a; // A�� �ּҷ� �ʱ�ȭ

    printf("A address : %u\n", &a);
    printf("PA : %u\n\n", pa);

    pa = a;
    printf("A address : %u\n", &a);
    printf("PA : %u\n\n", &pa);

    printf("PA�� Byte : %d", sizeof(pa));
    return 0;
}
