/**8char��
*/
#include<stdio.h>
int main()
{
    char ch;
    ch='A';//  ch=65;
    printf("ch : %c\n",ch);// A
    printf("ch : %d\n",ch);//'A'�� ASCII�ڵ尪 65
    return 0;
}
