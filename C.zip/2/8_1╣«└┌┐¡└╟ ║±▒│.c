#include <stdio.h>
#include <string.h>

int main()
{
    int n;
    n = strcmp("abc","ABC");
    printf("%d",n);
    return 0;
}
