#include <stdio.h>

int main()
{
    int score, input_cnt;
    char grade;

Re:

    printf("���� �Է�\t");
    input_cnt = scanf("%d", &score);


    if(score >= 90)
        grade = 'A';
    else if(score >= 80)
        grade = 'B';
    else if(score >= 70)
        grade = 'C';
    else if(score >= 60)
        grade = 'D';
    else
        grade = 'F';
    printf("���� : %3d\t�� : %c\r\n\r\n",score, grade);
    goto Re;


    return 0;
}
