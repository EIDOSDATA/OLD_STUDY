#!/bin/sh
case $1 in
0) systemctl start $2;;
1) systemctl stop $2;;
2) systemctl restart $2;;
3) systemctl status $2;;
*) echo "input (1-3)"
esac
exit 0
