#!/bin/bash

#for
for((i=0; i<=10; i++ ))
#for((i=0; $i<=10; i++ ))
	do
		echo $i
done

for((i=1; i<10; i+=2 ))
	do
		echo $i
done


for((i=10; i>0; i-=2 ))
	do 
		echo $i
done


#while
i=0
while [ $i -le 10 ]
do
	echo $i
	i=`expr $i + 1`
done
