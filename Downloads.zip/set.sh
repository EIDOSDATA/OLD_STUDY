#!/bin/bash

echo $(date)
set $(date)
echo $0-$1-$2

