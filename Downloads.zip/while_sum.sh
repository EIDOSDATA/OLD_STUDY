#!/bin/bash
sum_even=0
sum_odd=0
sum=0
i=0
while [ $i -lt 100 ]
do
	i=`expr $i + 1`
	if [ `expr $i % 2` -eq 0 ]
	then
		sum_even=`expr $sum_even + $i`
	else
		sum_odd=`expr $sum_odd + $i`
	fi
	sum=`expr $sum + $i`
done
echo $sum_even
echo $sum_odd
echo $sum
