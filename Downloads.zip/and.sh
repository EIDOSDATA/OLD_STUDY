#!/bin/sh

#echo `expr 5 / 2`
#echo `expr 5 / 2`

# score 
# 1~100	print grade
#		90~99 A grade
#		80~89 B grade
#		70~79 C grade
#		60~69 D grade
#		0 ~ 59 F grade

# ! 1~100 print input(1~100) 


echo "score : "
read score
if [ $score -ge 0 ] && [ $score -le 100 ]
then
	case `expr $score / 10` in
	10) echo "A grade";;
	9) echo "A grade";;
	8) echo "B grade";;
	7) echo "C grade";;
	6) echo "D grade";;
	*) echo "F grade";;
	esac
else
	echo "input (1~100)"
fi
