#!/bin/sh
var=10
#var = 20	# white space
#var=Hello Shell
var="Hello Shell"
var=10+20


echo "var : " $var
echo "var : " \$var
echo "var : " "

exit 0
