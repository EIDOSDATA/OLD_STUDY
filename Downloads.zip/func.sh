#!/bin/bash


disp() {
	echo "Hello Shell!!"
}

disp
disp
disp

echo "Hello Shell!!!"
echo "Hello Shell!!!"
echo "Hello Shell!!!"



hap() {
	return `expr 5 + 2`
}
hap
echo "hap : " $?

sum() {
	return `expr $1 + $2`
}
sum 10 20
echo "sum : " $?
