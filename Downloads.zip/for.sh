#!/bin/sh

#for i in 1 2 3 4 5
#for i in $(seq 1 10 )
#for i in $(seq 1 2 10 ) 


#!/bin/bash
sum=0
for((i=1;i<=10;i++ ))
do
	sum=`expr $sum + $i`
done
echo "sum : " $sum
exit 0
