#!/bin/sh
a="Hello"
b="Hello"

if [ $a = $b ]
then
	echo "true"
else
	echo "false"
fi



if test [$a-eq$b] 
then
	echo "true"
else
	echo "false"
fi



if test [10-eq10] 
then
	echo "true"
else
	echo "false"
fi



exit 0
