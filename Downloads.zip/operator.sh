#!/bin/sh
num1=10
num2=20
result=$num1+$num2
result=`expr $num1+$num2`
result=`expr $num1 + $num2`

result=`expr \( $num1 + $num2 \) / 2`
result=`expr \( $num1 + $num2 \) \* 2`

echo "result : " $result

echo "\$0: " $0
echo "\$1: " $1
echo "\$2: " $2
echo "\$3: " $3
echo "\$*: " $*


exit 0
