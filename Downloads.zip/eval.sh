#!/bin/sh
echo "ls -al" + " /"	# error
eval "ls -al" + " /"	# ls -al /
