#!/bin/sh
echo "USER : " $USER
exit "HOME : " $HOME
exit 0
