#!/bin/sh
fname="/root/a.txt"
if [ -e $fname ]; then
	if [ -f $fname ]; then
		head -5 $fname
	else
		echo "$name Directory"
	fi
else
	ls -l > $fname
fi

exit 0
