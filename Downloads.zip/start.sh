#!/bin/bash
set $(date)
echo $5 " : Hello" >> a.txt
cp /root/a.txt /root/b.txt

#oracle
#Django Web Server
#hadoop
#spark
#sqoop
