from product.models import Product
from order.models import Order
from member.models import Sign
from django.core.exceptions import ObjectDoesNotExist
from django.http.response import HttpResponse, Http404
from django.template import loader
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

def cart(request):
    template = loader.get_template( "cart.html" )
    memid = request.session.get("memid")
    pnum = request.GET.get("pnum") # GET으로 넘어오는 값
    user_id = request.GET.get("user_id") # GET으로 넘어오는 값
    product = Product.objects.get(pnum=pnum)
    try : 
        # 장바구니는 user를 FK 참조 save()를 위해 user가 누구인지도 알아야함
        cart = Order.objects.get(order_id_id = user_id, prod_num_id = pnum)
        if cart :
            if cart.prod_num.pnum == product.pnum :
                cart.save()
    except ObjectDoesNotExist :
        user = Sign.objects.get(user_id=user_id)
        cart = Order(
            order_id = user,
            prod_num = product,
            quan = 1,
            )
        cart.save()
    j = Order.objects.filter(order_id_id = user_id)
    total_price = 0
    for each_total in j :
        total_price += each_total.prod_num.price * each_total.quan
    
    context = {
        "cart":cart,
        "pnum":pnum,
        "user_id":user_id,
        "product":product,
        "memid":memid,
        "j":j,
        "total_price":total_price,
        }
    
    return HttpResponse( template.render( context, request ) )

def del_cart(request):
    onum = request.GET.get("onum")
    cart = Order.objects.get(onum=onum)
    cart.delete()  # delete 호출
    return redirect( "del_cart_pro" )
    
def del_cart_pro(request):
    memid = request.session.get( "memid" )
    cart = Order.objects.filter(order_id_id = memid)
    member = Sign.objects.get(user_id = memid)
    template = loader.get_template("cart_view.html")
    total_price = 0
    for each_total in cart :
        total_price += each_total.prod_num.price * each_total.quan
    context = {
        "memid":memid,
        "cart":cart,
        "member":member,
        "total_price":total_price,
        }
    return HttpResponse( template.render( context, request ) )

def cart_view(request):
    template = loader.get_template( "cart_view.html" )
    memid = request.session.get("memid")
    user_id = request.GET.get("user_id")
    cart = Order.objects.filter(order_id_id = user_id)
    member = Sign.objects.get(user_id = user_id)
    total_price = 0
    for each_total in cart :
        total_price += each_total.prod_num.price * each_total.quan
    context = {
        "memid":memid,
        "cart":cart,
        "member":member,
        "total_price":total_price,
        }
    
    return HttpResponse( template.render( context, request ) )

def add_cart(request):
    pnum = request.GET.get("pnum")
    product = Product.objects.get(pnum=pnum)
    user_id = request.GET.get("user_id")
    try :
        cart = Order.objects.get(prod_num_id = pnum)
        if cart :
            if cart.product.prod_num == product.prod_num :
                cart.quantity += 1
                cart.save()
    except Order.DoesNotExist :
        member = Sign.objects.get(user_id = user_id)
        cart = Order(
            member=member,
            product=product,
            # 장바구니에 해당 상품이 없을 경우 int 0을 선언
            quantity=0,
        )
        cart.save()
    return redirect('order:cart')

def minus_cart_item(request):
    pnum = request.GET.get("pnum")
    cart = Order.objects.filter(prod_num_id = pnum)
    product = Product.objects.get(pnum=pnum)
    try:
        for item in cart:
            if item.product.pname == product.pname :
                if item.quantity > 1 :
                    item.quantity -= 1
                    item.save()
                return redirect('order:cart')
            else:
                return redirect('order:cart')
    except Order.DoesNotExist :
        raise Http404