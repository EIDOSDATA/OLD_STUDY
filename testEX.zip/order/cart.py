from decimal import Decimal
from django.conf import settings
from product.models import Product

class Cart(object) :
    def __init__(self, request) :
    # 초기화 작업
        self.session = request.session
        cart = self.session.get(settings.CART_ID)
        # settings에 CART_ID라고 만들어줘야함
        if not cart :
            cart = self.session[settings.CART_ID] = {}
            # 새로운 dictionary 만들기
        self.cart = cart
    
    def __len__(self) :
    # 장바구니에 들어있는 상품의 갯수
        return sum(item["quantity"] for item in self.cart.values())
        # 장바구니의 제품들의 총 갯수
    
    def __iter__(self) :
    # for문 사용시 어떤 요소를 전달 할 것인지
        pnum = self.cart.keys()
        # 상품번호
        
        products = Product.objects.filter(id__in=pnum)
        # 특정 pnum에 해당되는 정보들만 모두 들고오기
        for pnum in products :
            self.cart[str(pnum)]["pnum"] = products
            # session에 저장할때는 숫자가 아닌 글자로 저장
            
        for item in self.cart.values() :
            item["price"] = Decimal(item["price"])
            # 상품 가격
            item["totp"] = item["price"] * item["quantity"]
            # 상품 총액 = 상품 가격 * 상품 갯수
            
            yield item
            # for문을 돌렸을 때 각 상품의 price와 totp 정보를 던져줌
    
    def add(self, product, quantity=1, is_update=False) :
    # is_update=False는 상세페이지에서 장바구니에 담기를 눌렀을 때 그 갯수를 더해지는 것이 아닌 선택한 갯수로 넘겨줌
        pnum = str(product.pnum)
        # 문자열로 저장하기 위해서 변경
        if pnum not in self.cart :
            self.cart[pnum] = {"quantity":0, "price":str(product.price)}
            # 제품정보 = 수량:0, 가격:소수점이 있는 경우를 위해 문자열(str)로 바꿔야함
        
        if is_update :
            self.cart[pnum]["quantity"] = quantity
            # 갯수 업데이트
        else :
            self.cart[pnum]["quantity"] += quantity
            # 갯수 추가
            
        self.save()
        
    def save(self) :
    # session에 정보 저장
        self.session[settings.CART_ID] = self.cart
        self.session.modified = True
        # True로 하지 않으면 정보를 업데이트하지 않음
        
        
    def remove(self, product) :
    # 상품 삭제
        pnum = str(product.pnum)
        # 문자열로 저장하기 위해서 변경
        if pnum in self.cart :
            del(self.cart[pnum])
            self.save()
    
    def clear(self) :
    # 장바구니 비우기
        self.session[settings.CART_ID] = {}
        self.session.modified = True
        # True로 하지 않으면 정보를 업데이트하지 않음
    
    def get_totp(self) :
    # 장바구니에 들어있는 상품 가격의 총합
        return sum((item["price"])*item["quantity"] for item in self.cart.values())