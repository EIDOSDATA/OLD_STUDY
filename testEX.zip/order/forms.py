from django import forms

# form을 사용하는 이유
# 사용자 화면에 입력 폼을 만들어주려고
# 사용자가 입력한 데이터에 대한 전처리(validation)

# model form은 회원가입시에 사용

class AddProductForm(forms.Form) :
# 일정한 양식만 가져다가 쓸 경우(ex.이메일 발송)
    quantity = forms.IntegerField()
    is_update = forms.BooleanField(required=False, initial=False, widget=forms.HiddenInput)
    # plist에서는 quantity가 1로 cart에서는 넘겨준 값이 표시됨
    # BooleanField는 required를 False로 해야함
    # HiddenInput은 사용자 화면에 보여주지 않을 경우에 사용