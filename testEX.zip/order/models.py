from django.db import models
from django.core.validators import MaxValueValidator, MinValueValidator
from product.models import Product
from member.models import Sign

# Create your models here.
class Order( models.Model) :
    onum = models.AutoField(verbose_name="주문번호", null=False, unique=True, primary_key=True)
    prod_num = models.ForeignKey(Product, verbose_name="상품코드", on_delete=models.CASCADE)
    order_id = models.ForeignKey(Sign, verbose_name="이름", on_delete=models.CASCADE)
    quan = models.PositiveSmallIntegerField(null=True, default=1, validators=[MinValueValidator(1), MaxValueValidator(100)], verbose_name="수량")
