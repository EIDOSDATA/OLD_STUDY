from django.contrib import admin

from order.models import Order

class OrderAdmin(admin.ModelAdmin) :
    list_display = (
        "onum",
        "prod_num",
        "order_id",
        "quan",
        )
admin.site.register(Order,OrderAdmin)