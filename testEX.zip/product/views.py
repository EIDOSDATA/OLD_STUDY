from django.http.response import HttpResponse
from django.template import loader
from .models import Product
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def necklace( request ):
    template = loader.get_template( "neckless.html" )
    memid = request.session.get( "memid" )
    prods = Product.objects.filter(bcate="Necklace")
    context = {
        "prods":prods,
        "memid":memid,
        }
    
    return HttpResponse( template.render( context, request ) )

@csrf_exempt
def earring( request ):
    template = loader.get_template( "earing.html" )
    memid = request.session.get( "memid" )
    prods = Product.objects.filter(bcate="Earring")
    context = {
        "prods":prods,
        "memid":memid,
        }
    
    return HttpResponse( template.render( context, request ) )

@csrf_exempt
def ring( request ):
    template = loader.get_template( "ring.html" )
    memid = request.session.get( "memid" )
    prods = Product.objects.filter(bcate="Ring")
    context = {
        "prods":prods,
        "memid":memid,
        } 
    return HttpResponse( template.render( context, request ) )

@csrf_exempt
def bracelet( request ):
    template = loader.get_template( "bracelet.html" )
    memid = request.session.get( "memid" )
    prods = Product.objects.filter(bcate="Bracelet")
    context = {
        "prods":prods,
        "memid":memid,
        }
    return HttpResponse( template.render( context, request ) )

@csrf_exempt
def plist( request ) :
    template = loader.get_template( "plist.html" )   
    pnum = request.GET.get( "pnum" )
    prod = Product.objects.get(pnum=pnum)
    memid = request.session.get( "memid" )
    context = {
        "memid":memid,
        "prod":prod,
        }
    return HttpResponse( template.render( context, request ) )
    