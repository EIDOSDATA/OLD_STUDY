BCATE_CHOICE = (
    ("Ring", "Ring"),
    ("Necklace", "Necklace"),
    ("Earring", "Earring"),
    ("Bracelet", "Bracelet")
    )

MCATE_CHOICE = (
    ("Bangle", "Bangle" ),
    ("Diamond", "Diamond" ),
    ("Pearl & Gem", "Pearl & Gem" ),
    ("String & Leather", "String & Leather" ),
    ("Long", "Long" ),
    ("Luxury", "Luxury" ),
    ("Pendant", "Pendant" ),
    ("Round", "Round" ),
    ("Y-drop", "Y-drop" ),
    ("Basic & Bubble", "Basic & Bubble" ),
    ("묵주", "묵주" ),
    ("Basic Pin", "Basic Pin" )
    )

BEST_CHOICE = (
    ("등록", "등록"),
    ("미등록", "미등록")
    )